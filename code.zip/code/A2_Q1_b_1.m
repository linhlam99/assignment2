clear
clc
set(0,'DefaultFigureWindowStyle','docked')
set(0,'defaultaxesfontsize',20)
set(0,'defaultaxesfontname','Times New Roman')
set(0,'DefaultLineLineWidth', 2);
L=300e-9;
W=200e-9; 
nx=50;
ny=40;
x = linspace(0,W,nx);
y = linspace(-L/2,L/2,ny);
V=zeros(nx,ny);
G=sparse(nx*ny,nx*ny);
V0=1;
F=zeros(nx*ny,1);
for i =1:nx
    for j=1:ny
       n = j+(i-1)*ny;
       if i ==1 || i ==nx
            F(n)=V0;
       elseif j==1 || j==ny
           F(n)=0;
       end
        if i==1 || j==1 || i==nx || j==ny
            G(n,n)=1;
        elseif i==1 && j==1
            G(n,n)=1;
       elseif i==1 && j==ny             
            G(n,n)=1; 
        else 
            nxm= j+(i-2)*ny;
            nxp=j+(i)*ny;
            nym=j-1+(i-1)*ny;
            nyp=j+1+(i-1)*ny;
            G(n,nxm)=1;
            G(n,nxp)=1;
            G(n,nyp)=1;
            G(n,nym)=1;
            G(n,n)=-4;
          end
end 
end
P=G\F;
for i=1:nx
    for j=1:ny
        n=j+(i-1)*ny;
        V(i,j)=P(n);
    end      
end
figure (1)
subplot(2,1,1)
[Gy,Gx] = meshgrid(y,x);
surf(Gy,Gx,V)
title('Solving Electrostatic Potential Using Finite Difference Method')
[Ex, Ey] = gradient(V);
subplot(2,1,2)
quiver(-Ey', -Ex', 10)

   
