clear
clc
close all
set(0,'DefaultFigureWindowStyle','docked')
set(0,'defaultaxesfontsize',20)
set(0,'defaultaxesfontname','Times New Roman')
set(0,'DefaultLineLineWidth', 2);
W=200e-9;
L=300e-9;
a=-0.5e-7;
Lb=1e-7;
d=0.5e-7; % adjust to narrow down the bottle-neck
Wb=W/2-d/2;
pin=1e-2; % conductivity inside the box
pout=1; %conductivity outside the box
for nx=15:10:200
    ny=round((2/3).*nx);
    x=linspace(-L/2,L/2,nx);
    y=linspace(0,W,ny);
    V=zeros(nx,ny);
    G=sparse(nx.*ny,nx.*ny);
    V0=1;
    F=zeros(nx.*ny,1);
    C=pout*ones(nx,ny); % define conductivity
    for i=1:nx
        for j=1:ny
            if x(i)>a && x(i)<a+Lb && (y(j)<Wb || y(j)>Wb+d)
                C(i,j) = pin;   
            end
        end 
    end
    for i =1:nx
        for j=1:ny 
           n = j+(i-1)*ny;
           if i ==1 
                F(n)=V0;
           elseif i ==nx
                F(n)=0;
           end
         
        if i==1 || i==nx 
            G(n,n) = 1;   
        elseif j==1 
            nxm= j+(i-2)*ny;
            nxp=j+(i)*ny;
            nyp=j+1+(i-1)*ny;
            cxm = (C(i-1,j)+C(i,j))/2;
            cxp = (C(i+1,j)+C(i,j))/2;
            cyp = (C(i,j+1)+C(i,j))/2;
           G(n,nxm)=cxm;
           G(n,nxp)=cxp;
           G(n,nyp)=cyp;
           G(n,n)=-(cxm+cxp+cyp);
        elseif j ==ny
            nxm= j+(i-2)*ny;
            nxp=j+(i)*ny;
           nym=j-1+(i-1)*ny;
           cxm = (C(i-1,j)+C(i,j))/2;
           cxp = (C(i+1,j)+C(i,j))/2;
           cym = (C(i,j-1)+C(i,j))/2;
          G(n,nxm)=cxm;
           G(n,nxp)=cxp;
           G(n,nym)=cym;
           G(n,n)=-(cxm+cxp+cym);
        else 
            nxm= j+(i-2)*ny;
            nxp=j+(i)*ny;
            nym=j-1+(i-1)*ny;
            nyp=j+1+(i-1)*ny;
            cxm = (C(i-1,j)+C(i,j))/2;
            cxp = (C(i+1,j)+C(i,j))/2;
            cym = (C(i,j-1)+C(i,j))/2;
            cyp = (C(i,j+1)+C(i,j))/2;
            G(n,nxm)=cxm;
            G(n,nxp)=cxp;
            G(n,nyp)=cyp;
            G(n,nym)=cym;
            G(n,n)=-(cxm+cxp+cyp+cym);
        end
        end
    end 
    P=G\F;
    for i=1:nx
        for j=1:ny
            n=j+(i-1)*ny;
            V(i,j)=P(n);
        end      
    end
    [Ey, Ex] = gradient(V);
    E=sqrt(Ex.^2+Ey.^2);
    Jx=C.*Ex;
    J_mean=mean(Jx(:,1))*W;
    hold on
    plot(nx,J_mean','*')
    title('The graph of current versus mesh size')
end