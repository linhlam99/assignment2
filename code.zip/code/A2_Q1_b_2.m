clear
clc
set(0,'DefaultFigureWindowStyle','docked')
set(0,'defaultaxesfontsize',20)
set(0,'defaultaxesfontname','Times New Roman')
set(0,'DefaultLineLineWidth', 2);
W=200e-9;
L=300e-9;
nx=50;
ny=40;
V0=1;
C=(4*V0)/pi;
a=W;
b=L/2;
x=linspace(-b,b,ny);
y=linspace(0,a,nx);
[X,Y] = meshgrid(x,y);
S=zeros(nx,ny);
for k=1:2:300
    V=C.*(1/k)*cosh(k.*pi.*X/a)./cosh(k.*pi.*b/a).*sin(k.*pi.*Y/a);
    S=S + V;
    figure (2)
    subplot(2,1,1)
    surf(S)
    pause(0.01)
end
title('Solving Electrostatic Potential Using Analytical Method');
[Ex, Ey] = gradient(S);
subplot(2,1,2)
quiver(-Ex, -Ey,10)   